# liveness_blink_check

face liveness blink detection activate, the script asks the person to generate an action, for example the action can be to blink eyes. after fulfilling all the actions it generates a message saying "liveness successful" or "liveness fail".


# How to install:

<pre><code>pip install -r requirements.txt </code></pre>

<pre><code>python liveness_smile_detection.py </code></pre>
